Sandra Suttiratana: suttiras@ucla.edu
Sarah Suttiratana: srsuttiratana@ucla.edu

We modified main.cc to test our program instead of using SqlEngine.cc. So there are modifications in main.cc.
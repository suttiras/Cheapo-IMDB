<html style = "font-family:Trebuchet MS">
<head>
	<title>IMDB: Cheapo Version</title>
</head>
<body>
<p style="text-align:center"><a href="./Homepage.php"><img src="ImdbLogo.png" alt="Website Logo"></a></p>
<!--<h1 style="text-align:center"><font size = "5"><b>Programmed by the Twins</b></font></h1>-->
<h2 style="text-align:center"><font size = "3"><b>For those who are too lazy to visit Imdb.com (or somehow don't know that it exists)</b></font></h2>
<p style="text-align:center"><font size = "2">We at IMDB: Cheapo Version desperately need your help in improving our website! Our budget is EXTREMELY tight.</p> 
<p style="text-align:center"><font size = "2">Please add actors, directors, etc. Preferably REAL ones. Thank you for your cooperation. </p>
<p style="text-align:center"><font size = "2">-the IMDB Cheapo Version team</p>
<p style="text-align:center">
<!--
<div style="text-align:center;width:200px;height:100px;padding:10px;border:10px outset yellowgreen;">
We at IMDB: Cheapo Version desperately need your help in improving our website! Our budget is EXTREMELY tight.
</div>
</p><-->

<p style="text-align:center">
<a href="./search.php">Search</a>
</p>

<h2 style="text-align:center"><font size = "3"><b>Add to Database</b></font></h2>
<p style="text-align:center">
<a href="./add_person.php">Actor/Director</a>
</p>
<p style="text-align:center">
<a href="./add_movie.php">Movie</a>
</p>
<p style="text-align:center">
<a href="./add_comments.php">Reviews</a>
</p>
<p style="text-align:center">
<a href="./actor_to_movie.php">Add an Actor to a Movie</a>
</p>
<p style="text-align:center">
<a href="./director_to_movie.php">Add a Director to a Movie</a>
</p>
<p></p>
<h2 style="text-align:center"><font size = "3"><b>Browse Database</b></font></h2>
<p style="text-align:center">
<a href="./browse_actor.php">Actor</a>
</p>

<p style="text-align:center">
<a href="./browse_movie.php">Movie</a>
</p>

</body>
</html>
In our project, we implemented a website that contains the basic functionality specified in the spec.
We made all 8 pages. One page is a search page to search for all actors and movies in the database.
We also made two browsing pages that show actor and movie information, but only if a user searches the actor or movie.
That is, if the user searches "Brad Pitt" in the search page, then the link from the search page will
lead to the actor browsing page which will display Brad Pitt's actor information. The movie browsing page
functions the same way. However, the movie browsing page will also display a link to add a review for that
movie. If the user clicks on the link, it will lead to the review page with the movie already in the 
dropdown menu.
If a user clicks on the Browse Actor or Browse Movie page, then there will be a link
stating that the user should click on the search link to browse actors and movies.
We lastly made 5 input pages that let users all the necessary information to add actors, directors, movies,
reviews, actors to movies relations, and director to movie relations. 
Our website is somewhat based on the demo website, in terms of dropdown menus, genre checkboxes, etc. We
could make the website more visually appealing if we had more time.
Basically, we covered all the necessary functionality.
We used pair programming and GitHub. Using GitHub proved extremely useful.